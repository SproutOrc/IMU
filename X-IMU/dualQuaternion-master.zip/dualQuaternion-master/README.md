dualQuaternion
==========

out of the box quaternions for c++

o quaternions with logarithm and exponential map
o dual quaternions with logarithm and exponential map
